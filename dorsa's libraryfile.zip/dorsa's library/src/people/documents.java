package people;

import people.writer;

import java.io.Serializable;

public class documents implements Serializable {
    protected String name;
    protected int id;
    protected int year;
    protected writer[] writers;

    public documents(String name, int id, int year, writer[] writers) {
        this.name = name;
        this.id = id;
        this.year = year;
        this.writers = writers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public writer[] getWriters() {
        return writers;
    }

    public void setWriters(writer[] writers) {
        this.writers = writers;
    }
}
