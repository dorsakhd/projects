package people;

import java.io.Serializable;

public class librarian extends person implements Serializable {
    public librarian(String firstname, String lastname, int id, int age) {

        super(firstname, lastname, id, age);
    }
}
