package people;

import java.io.*;
import java.lang.reflect.Member;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	library library=new library("dorsa");
	load(library);
	Scanner in = new Scanner(System.in);
whileloop:	while (true){
        String n =in.next();
switch (n){
    case "add":
        String a=in.next();
        switch (a){
            case "member":
                try {
                    String firstname=in.next();
                    String lastname=in.next();
                    int id=in.nextInt();
                    String provincename=in.next();
                    String townname =in.next();
                    String streetname =in.next();
                    int plaque=in.nextInt();
                    address address= new address(provincename,townname,streetname,plaque);
                    library.addmember(new member(firstname,lastname,id,address));
                }catch (InputMismatchException e){
                    e.printStackTrace();
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    break;
                }
            case "people.book":
                String name=in.next();
                int Id=in.nextInt();
                int writer =in.nextInt();
                int year=in.nextInt();
                people.writer[] writers=new writer[writer];
                for (int i = 0; i <writer ; i++) {
                    String writerfirstname=in.next();
                    String writerlastname=in.next();
                    writers[i]=new writer(writerfirstname,writerlastname);
                }
                book book=new book(name,Id,year,writers);
                break;
            case"item":

                 int memberid=in.nextInt();
                 int bookid=in.nextInt();
                 try {
                     library.getborrow(memberid).addborrowbook(library.getbook(bookid));
                 }catch (Exception e)
                 {
                     e.printStackTrace();
                 }finally {
                     break;
                 }
                }
            case"people.borrow":
                int memberrid=in.nextInt();
                int ID=in.nextInt();
                try {
                    library.addborrowed(new borrow(library.getmember(memberrid),ID,library));
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    break;
                }

    case "remove":
        String b=in.next();
        switch (b){
            case "item":
                try {
                    int memberid=in.nextInt();
                    int bookid=in.nextInt();
                    library.getborrow(memberid).removeborrowbook(library.getbook(bookid));
                }catch (InputMismatchException e){
                    e.printStackTrace();
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    break;
                }
        }
        break;
    case "report":
        String c=in.next();
        switch (c){
            case "customors":
                try {
                    for (int i = 0; i < library.getMembers().length; i++) {
                        member MEMBER=library.getMembers()[i];
                        if(MEMBER!=null)
                            System.out.println(MEMBER.getId()+","+MEMBER.getFirstname()+","+"0"+","+ MEMBER.getAddress().toString());
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    break;
                }

            case"people.borrow":
                break;
            case"people.book":
                break;
        }
        break;
    case "terminate":
        try {
            FileOutputStream file = new FileOutputStream(new File("library.txt"));
            ObjectOutputStream object = new ObjectOutputStream(file);
            object.writeObject(library);
            object.close();
            file.close();
            System.out.println("file save successfully");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            break whileloop;
        }

}

    }
    }
    public static void load(library library){

        try {
            FileInputStream     fileInputStream = new FileInputStream("library.txt");
            ObjectInputStream objectInputStream =new ObjectInputStream(fileInputStream);
            library = (library) objectInputStream.readObject();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
