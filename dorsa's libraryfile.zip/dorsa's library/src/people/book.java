package people;

import java.io.Serializable;

public class book extends documents implements Serializable {
    public book(String name, int id, int year, writer[] writers) {
        super(name, id, year, writers);
    }
}
