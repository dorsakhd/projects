package people;

import java.io.Serializable;

public class library implements Serializable {
    private String name;
    private member[] members=new member[10];
    private book[] books=new book[10];
    private book[] borrowed=new book[10];
    private book[] notborrowed=new book[10];
    private borrow[] borrows=new borrow[10];

    public library(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public member[] getMembers() {
        return members;
    }

    public void setMembers(member[] members) {
        this.members = members;
    }

    public book[] getBooks() {
        return books;
    }

    public void setBooks(book[] books) {
        this.books = books;
    }

    public book[] getBorrowed() {
        return borrowed;
    }

    public void setBorrowed(book[] borrowed) {
        this.borrowed = borrowed;
    }

    public book[] getNotborrowed() {
        return notborrowed;
    }

    public void setNotborrowed(book[] notborrowed) {
        this.notborrowed = notborrowed;
    }

    public borrow[] getBorrows() {
        return borrows;
    }

    public void setBorrows(borrow[] borrows) {
        this.borrows = borrows;
    }

    public void addborrowedbooks(book book) {
            for (int i = 0; i <notborrowed.length ; i++) {
                if(notborrowed[i]==book){
                    books[i]=null;
                    for (int j = 0; j <borrowed.length ; j++) {
                        if(borrowed[j]==null){
                            borrowed[j]=book;
                            break;
                        }
                    }
                    break;
                }
            }
    }

    public void removeborrowedbooks(book book) {
        for (int i = 0; i <borrowed.length ; i++) {
            if(borrowed[i]==book){
                books[i]=null;
                for (int j = 0; j <notborrowed.length ; j++) {
                    if(notborrowed[j]==book){
                        notborrowed[j]=null;
                        break;
                    }
                }
                break;
            }
        }
    }
    public void addborrowed(borrow borrow){
        for (int i = 0; i <borrows.length ; i++) {
            if(borrows[i]==null){
                borrows[i]=borrow;
                break;
            }
        }
    }
    public void addmember(member member){
        for (int i = 0; i <members.length ; i++) {
            if(members[i]==null){
                members[i]=member;
                break;
            }
        }
    }
    public void addbook(book book){
        for (int i = 0; i <books.length ; i++) {
            if(books[i]==null){
                books[i]=book;
                break;
            }
        }
    }
    public void addnotborrowed(book book){
        for (int i = 0; i <notborrowed.length ; i++) {
            if(notborrowed[i]==null){
                notborrowed[i]=book;
                break;
            }
        }
    }
    public member getmember(int id){
        for (int i = 0; i <members.length ; i++) {
            if(members[i]!=null){
            if(members[i].getId()==id){
                return members[i];
            }}
        }return null;
    }
    public book getbook(int id){
        for (int i = 0; i <books.length ; i++) {
            if(books[i]!=null){
            if(books[i].getId()==id){
                return books[i];
            }}
        }return null;
    }
    public borrow getborrow(int id){
        for (int i = 0; i <borrows.length ; i++) {
            if(borrows[i]!=null){
            if(borrows[i].getId()==id){
                return borrows[i];
            }}
        }return null;
    }

}
