package people;

import java.io.Serializable;

public class person implements Serializable {
    protected String firstname;
    protected String lastname;
    protected int id;
    protected int age;

    public person(String firstname, String lastname, int id, int age) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.id = id;
        this.age = age;
    }

    public person(String firstname, String lastname, int id) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.id = id;
    }

    public person(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
