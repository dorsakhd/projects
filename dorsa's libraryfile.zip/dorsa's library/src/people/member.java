package people;

import java.io.Serializable;

public class member extends person implements Serializable {
    private  address address;
    public member(String firstname, String lastname, int id,address address) {
        super(firstname, lastname, id);
        this.address=address;
    }

    public people.address getAddress() {
        return address;
    }
}
