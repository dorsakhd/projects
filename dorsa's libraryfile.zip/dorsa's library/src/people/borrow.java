package people;

import java.io.Serializable;

public class borrow implements Serializable {
    private member member;
    private int id;
    private int borrowed=0;
    private book[] books=new book[10];
    private library library;

    public borrow(people.member member, int id, library library) {
        this.member = member;
        this.id = id;
        this.library = library;
    }

    public people.member getMember() {
        return member;
    }

    public int getId() {
        return id;
    }

    public int getBorrowed() {
        return borrowed;
    }

    public book[] getBooks() {
        return books;
    }
    public void addborrowbook(book book){
        for (int i = 0; i <books.length ; i++) {
            if(books[i]==null){
                books[i]=book;
                break;
            }
            borrowed++;
            library.addborrowedbooks(book);
        }
    } public void removeborrowbook(book book){
        for (int i = 0; i <books.length ; i++) {
            if(books[i]==book){
                books[i]=null;
                break;
            }
            borrowed--;
            library.removeborrowedbooks(book);
        }
    }
}
