package people;

import java.io.Serializable;

public class writer extends person implements Serializable {
    public writer(String firstname, String lastname) {
        super(firstname, lastname);
    }
}
