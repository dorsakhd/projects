package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

import static javafx.scene.text.Font.*;

public class Time {
    private int x;
    private int y;
    private int width;
    private int height;
    private Image image;
    private Text text;
    private int x2;
    private int y2;
    private int hour;
    private int minute;
    private int second;
    public Time(int x, int y, int width, int height, Image image,Text text,int x2,int y2,int hour,int minute,int second) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.text=text;
        this.x2=x2;
        this.y2=y2;
        this.hour=hour;
        this.minute=minute;
        this.second=second;
    }
    public void addToPane6(Pane pane) {
        ImageView imageView = new ImageView(image);
        imageView.setX(x);
        imageView.setY(y);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        pane.getChildren().add(imageView);
    }

    public void addToPane7(Pane pane){
        Text text = new Text();
        text.setX(x2);
        text.setY(y2);
        text.getText();
        text.setFill(Color.BLACK);
        text.setScaleY(2);
        text.setScaleX(2);
        pane.getChildren().add(text);
    }
    public void start(Pane pane){
        Timeline timeline = new Timeline();
        KeyFrame kf = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                second--;
                if (second == 0) {
                    second = 60;
                    minute--;
                    if (minute == 0) {
                        minute = 60;
                        hour--;
                    }
                }
              text.setText(hour+ ":"+minute+":"+second);
            }
        });
        text.setX(x2);
        text.setY(y2);
        text.setScaleY(2);
        text.setScaleX(2);
        text.setFont(Font.font ("Arial", 11));
        text.setFill(Color.BLUE);

        pane.getChildren().add(text);
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.getKeyFrames().add(kf);
        timeline.play();

    }
}
