package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.sql.Time;

public class turttle {
    private double x;
    private double y;
    private int width;
    private int height;
    private Image image;
    private int speed;
    private boolean direction;
    private int dx = 1;
    private int rotate = 0;
    private double start;
    private double end;
    public turttle(double x, double y, int width, int height, Image image, int speed, boolean direction,double start,double end) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.speed = speed;
        this.direction = direction;
        this.dx = dx;
        this.rotate = rotate;
        this.start=start;
        this.end=end;
    }

    public void addToPaneAndMove(Pane pane) {
        ImageView imageView = new ImageView(image);
        imageView.setX(x);
        imageView.setY(y);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        pane.getChildren().add(imageView);
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        KeyFrame kf = new KeyFrame(Duration.millis(speed * 20), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (imageView.getX()>=end && direction) {
                    dx = -dx;
                    rotate = 180;
                    imageView.setRotationAxis(Rotate.Y_AXIS);
                    imageView.setRotate(rotate);
                    direction=false;
                }
//                imageView.setX(imageView.getX() + dx);
                 if (imageView.getX() <=start && !direction) {
                    dx = -dx;
                    rotate = 0;
                    imageView.setRotationAxis(Rotate.Y_AXIS);
                    imageView.setRotate(rotate);
                    direction=true;
                }
                imageView.setX(imageView.getX() + dx);
            }
        });
        timeline.getKeyFrames().add(kf);
        timeline.play();
    }
}

