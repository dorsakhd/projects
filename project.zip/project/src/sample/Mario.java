package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

import java.io.Serializable;

public class Mario implements Serializable {
    private int x;
    private int y;
    private int width;
    private int height;
    private transient Image image;
    private int speed;
    private boolean direction;
    private int dx = 1;
    private int rotate = 0;

    public Mario(int x, int y, int width, int height, Image image, int speed, boolean direction) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.speed = speed;
        this.direction = direction;
        this.dx = dx;
        this.rotate = rotate;
    }

    public static Mario forName(String s) {

        return null;
    }

    public void addToPaneAndMovem(Pane pane) {
        ImageView imageView = new ImageView(image);
        imageView.setX(x);
        imageView.setY(y);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        pane.getChildren().add(imageView);
        imageView.setFocusTraversable(true);
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        imageView.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                switch (keyEvent.getCode()){
                    case LEFT:
                        Timeline timeline = new Timeline();
                        timeline.setCycleCount(Timeline.INDEFINITE);
                        KeyFrame kf = new KeyFrame(Duration.millis(3000), new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent actionEvent) {
                                imageView.setTranslateX(imageView.getTranslateX()-5);
                            }
                        });
                        timeline.getKeyFrames().add(kf);
                        timeline.play();
                        break;
                }
            }
        });
    }

    @Override
    public String toString() {
        return "Mario{" +
                "x=" + x +
                ", y=" + y +
                ", width=" + width +
                ", height=" + height +
                ", image=" + image +
                ", speed=" + speed +
                ", direction=" + direction +
                ", dx=" + dx +
                ", rotate=" + rotate +
                '}';
    }
}