package sample;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class Score {
    private int x;
    private int y;
    private int width;
    private int height;
    private Image image;
    private Text text;
    private int x2;
    private int y2;
    public Score(int x, int y, int width, int height, Image image,Text text,int x2,int y2) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.text=text;
        this.x2=x2;
        this.y2=y2;
    }
    public void addToPane3(Pane pane) {
        ImageView imageView = new ImageView(image);
        imageView.setX(x);
        imageView.setY(y);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        pane.getChildren().add(imageView);
    }

    public void addToPane4(Pane pane){
        Text text = new Text();
        text.setX(x2);
        text.setY(y2);
        text.setText("0");
        text.getText();
        text.setFill(Color.BLACK);
        text.setScaleY(3);
        text.setScaleX(3);
        pane.getChildren().add(text);
    }
}
