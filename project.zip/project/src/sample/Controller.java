package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

public class Controller {
    @FXML
    AnchorPane mainPane;
    @FXML
    public void initialize()
    {
        Background background=new Background(0,0,2000,1000,new Image("images/171-1717739_cute-light-pink-wallpapers-57-images-light-pink.jpg"));
        background.addToPane(mainPane);

//        turttle turtle = new turttle(350,300,100,50,new Image("images/turtle.gif"),5,true);
//        turtle.addToPaneAndMove(mainPane);
        Mario mario=new Mario(730,100,170,110,new Image("images/mario.gif"),5,true);
        mario.addToPaneAndMovem(mainPane);
        Mario mario2=new Mario(750,560,120,100,new Image("images/luigi.png"),5,true);
        mario2.addToPaneAndMovem(mainPane);
        Score score=new Score(1400,20,150,80,new Image("images/luigiscore.png"),new Text(),1490,65);
        score.addToPane3(mainPane);
        score.addToPane4(mainPane);
        Score score2=new Score(50,20,150,80,new Image("images/marioscore.png"),new Text(),150,65);
        score2.addToPane3(mainPane);
        score2.addToPane4(mainPane);
        Time time=new Time(740,20,150,80,new Image("images/time.png"),new Text(),830,65,1,2,50);
        time.addToPane6(mainPane);
        time.addToPane7(mainPane);
        time.start(mainPane);
        Button save=new Button("Save");
        mainPane.getChildren().add(save);
        save.setPrefWidth(100);
        save.setLayoutX(1100);
        save.setLayoutY(20);
        save.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    FileOutputStream file = new FileOutputStream(new File("save.text"));
                    ObjectOutputStream object = new ObjectOutputStream(file);

                    object.writeObject(mario);
                    object.close();
                    file.close();
                    System.out.println("file save successfully");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        Ajor ajors[]={new Ajor(0,780,800,100,new Image("images/brick1.png")),
                        new Ajor(800,780,800,100,new Image("images/brick1.png")),
                        new Ajor(700,200,200,50,new Image("images/brick1.png")),
                        new Ajor(0,350,750,50,new Image("images/brick1.png")),
                        new Ajor(850,350,750,50,new Image("images/brick1.png")),
                        new Ajor(400,500,800,50,new Image("images/brick1.png")),
                        new Ajor(0,500,300,50,new Image("images/brick1.png")),
                        new Ajor(1300,500,300,50,new Image("images/brick1.png")),
                        new Ajor(700,650,200,50,new Image("images/brick1.png")),
                        new Ajor(0,650,600,50,new Image("images/brick1.png")),
                        new Ajor(1000,650,600,50,new Image("images/brick1.png"))};
        for (int i=0;i<11;i++)
        {
            ajors[i].addToPane5(mainPane);
        }
        double[][] turtls=new double[11][3];
        for (int i=0;i<11;i++){
             turtls[i][0]=ajors[i].getX();
             turtls[i][1]=ajors[i].getY()-55;
             turtls[i][2]=ajors[i].getWidth();
        }
        Random random=new Random();
        int[] x=new int[3];
        for (int i=0;i<3;i++){
            x[i]=random.nextInt(10);
        }
        turttle turttle1[]={
                new turttle(random.nextDouble()*(turtls[x[0]][2]-150)+turtls[x[0]][0],turtls[x[0]][1]+10,150,55, new Image("images/turtle.gif"),random.nextInt(5)+1,true,ajors[x[0]].getX(),ajors[x[0]].getX()+ajors[x[0]].getWidth()-150),
                new turttle(random.nextDouble()*(turtls[x[1]][2]-150)+turtls[x[1]][0],turtls[x[1]][1]+10,150,55, new Image("images/turtle.gif"),random.nextInt(5)+1,true,ajors[x[1]].getX(),ajors[x[1]].getX()+ajors[x[1]].getWidth()-150),
                new turttle(random.nextDouble()*(turtls[x[2]][2]-150)+turtls[x[2]][0],turtls[x[2]][1]+10,150,55, new Image("images/turtle.gif"),random.nextInt(5)+1,true,ajors[x[2]].getX(),ajors[x[2]].getX()+ajors[x[2]].getWidth()-150)};
        turttle1[0].addToPaneAndMove(mainPane);
        turttle1[1].addToPaneAndMove(mainPane);
        turttle1[2].addToPaneAndMove(mainPane);
        Blackhole blackhole=new Blackhole(680,270,100,80,new Image("images/blackhole .png"));
        blackhole.addToPane8(mainPane);
        Blackhole blackhole2=new Blackhole(1100,420,110,80,new Image("images/blackhole2.png"));
        blackhole2.addToPane8(mainPane);
        Tunnel tunnel=new Tunnel(0,270,150,80,new Image("images/tunnel.png"));
        tunnel.addToPane9(mainPane);
        Tunnel tunnel2=new Tunnel(1450,700,150,80,new Image("images/tunnel2.png"));
        tunnel2.addToPane9(mainPane);



            }

        }


