package people;

public class book extends documents {
    public book(String name, int id, int year, writer[] writers) {
        super(name, id, year, writers);
    }
}
