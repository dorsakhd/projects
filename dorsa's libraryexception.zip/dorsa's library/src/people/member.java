package people;

public class member extends person {
    private  address address;
    public member(String firstname, String lastname, int id,address address) {
        super(firstname, lastname, id);
        this.address=address;
    }

    public people.address getAddress() {
        return address;
    }
}
