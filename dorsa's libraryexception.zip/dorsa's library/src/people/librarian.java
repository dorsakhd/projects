package people;

public class librarian extends person {
    public librarian(String firstname, String lastname, int id, int age) {

        super(firstname, lastname, id, age);
    }
}
