package people;

public class writer extends person {
    public writer(String firstname, String lastname) {
        super(firstname, lastname);
    }
}
