package sample;

import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;

public class Person {
    public Person(TextField first, TextField last, Slider age1, Label id, Label password) {

    }
}
